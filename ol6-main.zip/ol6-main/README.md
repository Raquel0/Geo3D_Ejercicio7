# ol6
Integraciòn sencilla TR3 con openlayers 6

## Demo en vivo
http://terre3.es/dev/example/ol6/

## Documentación
